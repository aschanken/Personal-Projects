from huggingface_hub import snapshot_download
snapshot_download(repo_id="MonsterMMORPG/SECourses_SUPIR",local_dir="SUPIR/models")